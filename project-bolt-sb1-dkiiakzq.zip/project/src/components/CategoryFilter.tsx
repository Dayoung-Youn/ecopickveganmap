import { Leaf, Recycle, Coffee, Store, Utensils, ShoppingBag, X } from 'lucide-react';

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  비건: <Leaf size={14} />,
  제로웨이스트: <Recycle size={14} />,
  카페: <Coffee size={14} />,
  식당: <Utensils size={14} />,
  샵: <ShoppingBag size={14} />,
  스토어: <Store size={14} />,
};

interface CategoryFilterProps {
  categories: string[];
  active: string | null;
  onSelect: (cat: string | null) => void;
}

export default function CategoryFilter({ categories, active, onSelect }: CategoryFilterProps) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto px-1 py-1 scrollbar-hide">
      <button
        onClick={() => onSelect(null)}
        className={`flex items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 ${
          active === null
            ? 'bg-olive-600 text-white shadow-md'
            : 'bg-cream-100 text-charcoal-700 hover:bg-cream-200'
        }`}
      >
        <X size={12} />
        전체
      </button>
      {categories.map((cat) => (
        <button
          key={cat}
          onClick={() => onSelect(cat === active ? null : cat)}
          className={`flex items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 ${
            active === cat
              ? 'bg-olive-600 text-white shadow-md'
              : 'bg-cream-100 text-charcoal-700 hover:bg-cream-200'
          }`}
        >
          {CATEGORY_ICONS[cat] ?? <Leaf size={14} />}
          {cat}
        </button>
      ))}
    </div>
  );
}
