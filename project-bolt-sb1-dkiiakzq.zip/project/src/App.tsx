import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Compass, MapPin } from 'lucide-react';
import CategoryFilter from './components/CategoryFilter';
import PlacePopup from './components/PlacePopup';
import { fetchPlaces } from './lib/fetchPlaces';
import type { Place } from './lib/types';

mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN;

const CATEGORY_COLORS: Record<string, string> = {
  비건: '#7c8c5a',
  제로웨이스트: '#a3b18a',
  카페: '#c9a96e',
  식당: '#d4a373',
  샵: '#b5838d',
  스토어: '#6d6875',
};

export default function App() {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<{ [key: string]: mapboxgl.Marker }>({});

  const [places, setPlaces] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  // Initialize map
  useEffect(() => {
    if (map.current || !mapContainer.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [126.978, 37.5665],
      zoom: 11,
    });

    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
  }, []);

  // Fetch places
  useEffect(() => {
    fetchPlaces()
      .then(setPlaces)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const categories = useMemo(
    () => [...new Set(places.map((p) => p.category).filter(Boolean))],
    [places],
  );

  const filtered = useMemo(
    () => (activeCategory ? places.filter((p) => p.category === activeCategory) : places),
    [places, activeCategory],
  );

  const relatedPlaces = useMemo(() => {
    if (!selectedPlace) return [];
    return places.filter((p) => p.postUrl === selectedPlace.postUrl);
  }, [places, selectedPlace]);

  // Create markers
  useEffect(() => {
    if (!map.current) return;

    // Remove old markers
    Object.values(markersRef.current).forEach((marker) => marker.remove());
    markersRef.current = {};

    // Add filtered markers
    filtered.forEach((place) => {
      const color = CATEGORY_COLORS[place.category] ?? '#7c8c5a';
      const el = document.createElement('div');
      el.className = 'w-8 h-8 rounded-full cursor-pointer flex items-center justify-center transition-transform hover:scale-110';
      el.style.backgroundColor = color;
      el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.2)';

      const icon = document.createElement('svg');
      icon.innerHTML =
        '<path fill="white" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>';
      icon.setAttribute('width', '16');
      icon.setAttribute('height', '16');
      icon.setAttribute('viewBox', '0 0 24 24');
      el.appendChild(icon);

      if (selectedPlace?.name === place.name) {
        el.style.width = '36px';
        el.style.height = '36px';
        el.style.zIndex = '1000';
      }

      el.addEventListener('click', (e) => {
        e.stopPropagation();
        setSelectedPlace(place);
      });

      const marker = new mapboxgl.Marker({ element: el })
        .setLngLat([place.lng, place.lat])
        .addTo(map.current!);

      markersRef.current[place.name] = marker;
    });
  }, [filtered, selectedPlace]);

  const handleRecenter = useCallback(() => {
    if (map.current) {
      map.current.flyTo({ center: [126.978, 37.5665], zoom: 11, speed: 1.4 });
    }
  }, []);

  const handlePlaceClick = useCallback((place: Place) => {
    setSelectedPlace(place);
    if (map.current) {
      map.current.flyTo({ center: [place.lng, place.lat], zoom: 13, speed: 1.2 });
    }
  }, []);

  return (
    <div className="relative w-full h-full bg-cream-50">
      {/* Map */}
      <div ref={mapContainer} className="w-full h-full" />

      {/* Top overlay */}
      <div className="absolute top-0 left-0 right-0 z-10 pointer-events-none">
        <div className="flex items-center gap-3 px-4 pt-4 pb-2">
          {/* Logo */}
          <div className="flex items-center gap-2 bg-white/90 backdrop-blur-md rounded-2xl px-4 py-2.5 shadow-md pointer-events-auto">
            <div className="w-7 h-7 rounded-lg bg-olive-600 flex items-center justify-center">
              <Compass size={14} className="text-white" />
            </div>
            <span className="font-bold text-charcoal-800 text-sm tracking-tight">EcoMap</span>
          </div>

          {/* Recenter */}
          <button
            onClick={handleRecenter}
            className="pointer-events-auto flex items-center gap-1.5 bg-white/90 backdrop-blur-md rounded-2xl px-3 py-2.5 shadow-md text-sm font-medium text-charcoal-700 hover:bg-white transition-colors"
          >
            <MapPin size={14} className="text-olive-500" />
            서울
          </button>
        </div>

        {/* Category filter */}
        <div className="px-4 pointer-events-auto">
          <div className="bg-white/90 backdrop-blur-md rounded-2xl px-3 py-2 shadow-md">
            <CategoryFilter
              categories={categories}
              active={activeCategory}
              onSelect={setActiveCategory}
            />
          </div>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-cream-50/80 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-3">
            <div className="w-10 h-10 border-3 border-olive-200 border-t-olive-600 rounded-full animate-spin" />
            <p className="text-sm font-medium text-charcoal-600">장소를 불러오는 중...</p>
          </div>
        </div>
      )}

      {/* Place popup */}
      {selectedPlace && (
        <PlacePopup
          place={selectedPlace}
          related={relatedPlaces}
          onClose={() => setSelectedPlace(null)}
          onPlaceClick={handlePlaceClick}
        />
      )}
    </div>
  );
}
